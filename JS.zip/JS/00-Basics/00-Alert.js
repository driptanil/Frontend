alert("Hello JavaScript!");
// creates an alert in web page