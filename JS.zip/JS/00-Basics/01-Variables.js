/* 
-> variables cannot start with numbers
-> variable names cannot be keywords
-> variables cannot have any spaces
*/

let inbox = 100;
let user = 'Driptanil';
// declaring variables

console.log(user);


const count = 100;
// const is immutable like final

console.log(count);

let password;
// undefined

console.log(password);