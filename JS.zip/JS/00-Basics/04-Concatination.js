const bank1 = 100;
const bank2 = 50;

const allBanks = bank1 + bank2;

const greeting = "Welcome to Our Website, ";
const user = "\"Driptanil\"";
console.log(greeting + user);

const concat = `"Hey" there welcome ! to our '${user}'! `;
console.log(concat)