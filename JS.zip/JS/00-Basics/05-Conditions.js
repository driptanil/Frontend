let boolean; // undefined

boolean = 0;
boolean = false;
boolean = null;
boolean = "";

if (boolean) {
    console.log('True');
} else {
    console.log('False');
}